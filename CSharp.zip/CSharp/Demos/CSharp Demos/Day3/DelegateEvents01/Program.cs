﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateEvents01
{
 
     
    class Program
    {
        static void Main(string[] args)
        {
            AritmeticOperation operationObj = new AritmeticOperation();

            ArithmeticOp arithObj1, arithObj2, arithObj3, arithObj4, arithObj5;
            arithObj1 = new ArithmeticOp(operationObj.Addition);
            arithObj2 = new ArithmeticOp(operationObj.Subtraction);
            arithObj3 = new ArithmeticOp(operationObj.Multiplication);
            arithObj4 = new ArithmeticOp(operationObj.Division);
            arithObj5 = new ArithmeticOp(operationObj.Max);



            int x, y;
            Console.WriteLine("Enter the Choice \n 1. for Addition \n 2. for Subtraction \n 3. for Multiplication\n 4. for Division\n 5. for max no. ");
            int choice = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter 1st no");
            x = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter 2nd no");
            y = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1: //add
                    arithObj1(x, y);
                    break;
                case 2: //sub
                    arithObj2(x, y);
                    break;
                case 3: //mult
                    arithObj3(x, y);
                    break;
                case 4: //div
                    arithObj4(x, y);
                    break;
                case 5: //max
                    arithObj5(x, y);
                    break;



                default:
                    break;
            }

            

           

            Console.ReadKey();
        }
    }
}
