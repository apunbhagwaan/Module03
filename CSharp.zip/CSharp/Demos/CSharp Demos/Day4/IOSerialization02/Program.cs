﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/*
 * Program demonstrating BinaryReader and BinaryWriter
 */ 

namespace IOSerialization02
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream fileStream01 = new FileStream(@"C:\Users\pgawad\Desktop\test1.txt", FileMode.Create, FileAccess.Write);
            BinaryWriter binaryWriter = new BinaryWriter(fileStream01);
            binaryWriter.Write(54);
            binaryWriter.Write("IGATEPATNI");
            binaryWriter.Write(65.76);
            binaryWriter.Write("prachiti Gawad");
            binaryWriter.Close();
            fileStream01.Close();

            FileStream fileStream02 = new FileStream(@"C:\Users\pgawad\Desktop\test1.txt", FileMode.Open, FileAccess.Read);
            BinaryReader binaryReader = new BinaryReader(fileStream02);
            Console.WriteLine(binaryReader.ReadInt32());
            Console.WriteLine(binaryReader.ReadString());
            Console.WriteLine(binaryReader.ReadDouble());
            Console.WriteLine(binaryReader.ReadString());
            binaryReader.Close();
            fileStream02.Close();

            Console.ReadKey();
        }
    }
}
